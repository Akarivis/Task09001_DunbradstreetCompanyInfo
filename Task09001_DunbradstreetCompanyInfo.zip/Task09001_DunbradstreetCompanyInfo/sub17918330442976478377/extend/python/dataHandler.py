import json

import pymysql
import requests


def getConfig(machineCode):
    url="https://platform-rpa.myeverok.com/rest/getParam"
    data={
        "machineCode":machineCode
    }
    response=requests.post(url,json=data)
    config=json.loads(response.text).get("mapper")
    return config


def getQueryList(machine_code):
    config = getConfig(machine_code)
    connect_name = "connectInfoRPA"
    dict_rpa_url = json.loads(config[connect_name])
    with pymysql.connect(host=dict_rpa_url['host'], port=int(dict_rpa_url['port']),
                         user=dict_rpa_url['user'],
                         password=dict_rpa_url['password'], database=dict_rpa_url['database'],
                         charset=dict_rpa_url["charset"]) as mydb:
        with mydb.cursor() as cursor:
            sql = "select code,pt,cn_name,en_name,country_name,province_name,city_name,Region__c,Type from T02_BUSI_0900101_BASIC where status is Null"
            cursor.execute(sql)
            list_query = cursor.fetchall()
            query_list = []
            for row in list_query:
                query_list.append({
                    "code":row[0],
                    "pt": row[1],
                    "cn_name": row[2],
                    "en_name": row[3],
                    "country_name": row[4],
                    "province_name": row[5],
                    "city_name": row[6],
                    "Region__c": row[7],
                    "Type": row[8]
                })
            return query_list


def insertQueryData(jsonData,machine_code):
    config = getConfig(machine_code)
    connect_name = "connectInfoRPA"
    dict_rpa_url = json.loads(config[connect_name])
    with pymysql.connect(host=dict_rpa_url['host'], port=int(dict_rpa_url['port']),
                         user=dict_rpa_url['user'],
                         password=dict_rpa_url['password'], database=dict_rpa_url['database'],
                         charset=dict_rpa_url["charset"]) as mydb:
        with mydb.cursor() as cursor:
            list_insert = []
            for row in jsonData:

                list_insert_item = [row['customer_code'], row['customer_name_cn'], row['customer_name'], row['country_name'], row['province_name'], row['city_name'], row['website'],
                       row['email_address'], row['telephone_number'], row['financials_in'], row['employees'], row['D-U-N-S_Number'], row['address'], row['parent'],
                       row['global_ultimate'], row['corporate_linkage'], row['industry'], row['latitude'], row['longitude']]
                list_insert.append(list_insert_item)
            sql = """insert into T02_BUSI_0900102_QUERY_DATA(customer_code,customer_name_cn,customer_name,country_name,province_name,city_name,website,
            email_address,telephone_number,financials_in,employees,DUNS_Number,address,parent,global_ultimate,corporate_linkage,industry,latitude,longitude,handle_time) 
            values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW());"""
            cursor.executemany(sql,list_insert)

            sql = "update T02_BUSI_0900101_BASIC set status = 'Done',handle_time = NOW() where code = %s"
            cursor.execute(sql,[row['customer_code']])

            mydb.commit()
    return True




def updateStatus(sf_code,status,machine_code):
    config = getConfig(machine_code)
    connect_name = "connectInfoRPA"
    dict_rpa_url = json.loads(config[connect_name])
    with pymysql.connect(host=dict_rpa_url['host'], port=int(dict_rpa_url['port']),
                         user=dict_rpa_url['user'],
                         password=dict_rpa_url['password'], database=dict_rpa_url['database'],
                         charset=dict_rpa_url["charset"]) as mydb:
        with mydb.cursor() as cursor:
            sql = "update T02_BUSI_0900101_BASIC set status = %s,handle_time = NOW() where code = %s"
            cursor.execute(sql,[status,sf_code])
            mydb.commit()
    return True


















if __name__ == '__main__':
    machine_code = "5E15345E7A215F380A36"

#     # getQueryList(config)
#     jsonData= [
#         {
#                 "D-U-N-S_Number" : "34-113-0007",
#                 "address" : "Cargo City Süd 537f Frankfurt am Main, Hessen, 60549 Germany",
#                 "city_name" : "FrankfurtamMain",
#                 "corporate_linkage" : "2 Companies ",
#                 "country_name" : "Germany",
#                 "customer_code" : "A000842",
#                 "customer_name" : "aircargo trucking & handling GmbH",
#                 "customer_name_cn" : "aircargo trucking & handling GmbH",
#                 "email_address" : "info@ath.aero",
#                 "employees" : "27 (Total)",
#                 "financials_in" : "USD",
#                 "global_ultimate" : "",
#                 "industry" : "Road Transportation Services",
#                 "latitude" : "50.26226",
#                 "longitude" : "8.557585",
#                 "machine_code" : "8065680B8DFFF5DC0A64",
#                 "parent" : "",
#                 "province_name" : "Hessen",
#                 "telephone_number" : "+49-6927298860",
#                 "website" : "www.ath.aero"
#         },
#         {
#                 "D-U-N-S_Number" : "34-162-4608",
#                 "address" : "Gebäude  870 Hahn-Flughafen, Rheinland-Pfalz, 55483 Germany",
#                 "city_name" : "Hahn-Flughafen",
#                 "corporate_linkage" : "2 Companies ",
#                 "country_name" : "Germany",
#                 "customer_code" : "A000842",
#                 "customer_name" : "aircargo trucking & handling GmbH",
#                 "customer_name_cn" : "aircargo trucking & handling GmbH",
#                 "email_address" : "",
#                 "employees" : "27 (Global Ultimate Total)",
#                 "financials_in" : "USD",
#                 "global_ultimate" : "aircargo trucking & handling GmbH",
#                 "industry" : "Road Transportation Services",
#                 "latitude" : "49.951119",
#                 "longitude" : "7.277304",
#                 "machine_code" : "8065680B8DFFF5DC0A64",
#                 "parent" : "aircargo trucking & handling GmbH",
#                 "province_name" : "Rheinland-Pfalz",
#                 "telephone_number" : "www.ath.aero",
#                 "website" : "www.ath.aero"
#         }
# ]
#     insertQueryData(jsonData,machine_code)
    updateStatus('A001728','Except',machine_code)