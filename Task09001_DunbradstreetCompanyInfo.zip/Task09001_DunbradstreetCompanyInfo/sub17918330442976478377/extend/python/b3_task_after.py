import datetime
import ftplib
import json
import mimetypes
import os.path
import re

import pymssql
# import pdfplumber
# import pymssql
import pymysql
import requests
import urllib3
from requests_toolbelt import MultipartEncoder


def getConfig(machine_code):
    url = "https://platform-rpa.myeverok.com/rest/getParam"
    data = {
        "machineCode":machine_code
    }
    response = requests.post(url, json=data)
    config = json.loads(response.text).get("mapper")
    return config
# def parse_invoice_from_pdf(pdf_path):
#     # 定义正则表达式模式来匹配开票人和抬头
#     pattern = r"买\s*名称[:：]\s*(.*?)\s*售\s*名称[:：]\s*(.*)"
#     "买 名称:智慧恒通（江苏）供应链科技集团有限公司 售 名称:中国外运华东有限公司"
#     # 初始化结果
#     drawer = None
#     title = None
#
#     # 打开PDF文件
#     with pdfplumber.open(pdf_path) as pdf:
#         # 遍历每一页
#         for page in pdf.pages:
#             # 提取文本
#             text = page.extract_text()
#
#             if text:
#                 # 匹配文本
#                 match = re.search(pattern, text)
#
#                 if match:
#                     buyer_name = match.group(1).strip()  # 买方的公司名称
#                     seller_name = match.group(2).strip()  # 卖方的公司名称
#
#                     return {
#                         "开票人": seller_name,
#                         "抬头": buyer_name
#                     }
#                 else:
#                     return {
#                         "开票人": None,
#                         "抬头": None
#                     }

def get_error_message(error_message_map,error_code,variable_map):
    """
    根据error_code 获取提前配置的错误描述信息
    :param error_code:  错误码
    :param variable_map: 变量名对应的字典   与数据库里配置的错误信息里的变量名一一对应 例如{"BOOKINGREQ_ID":"123","BOOKING_COMPANY":"234","ROUTE_CODE":"999"}
    :return:
    """
    error_info=error_message_map.get(error_code)
    if not error_info:
        return f'警告！未找到该错误码{error_code}'
    message=error_info.get("cn")
    message_en=error_info.get("en")
    db_variable_map=error_info.get("variable_map")
    if (not message):
        return f'警告！未找到该错误码{error_code}的描述信息'
    if not message_en:
        error_message=f'f"""{message}"""'
    else:
        error_message = f'f"""{message}\n\n\n{message_en}"""'
    """变量初始化赋值"""
    for key,value in db_variable_map.items():
        exec(f"global {key}\n{key}=None")
    """变量赋值"""
    for key,value in variable_map.items():
        exec(f"global {key}\n{key}='{value}'")
    error_message=eval(error_message)
    return error_message


class WinxinApi(object):
    def __init__(self, corpid, secret, agentid, touser='', chatid=''):
        self.secret = secret  # 企业微信应用凭证
        self.corpid = corpid  # 企业微信id
        self.agentid = agentid  # 应用Agentid
        self.touser = touser  # 接收消息的userid
        self.chatid = chatid  # 接收消息的群id
        self.http = urllib3.PoolManager()

    def __get_token(self):
        # '''token获取'''
        url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={}&corpsecret={}".format(self.corpid, self.secret)
        r = self.http.request('GET', url)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            return data['access_token']
        else:
            raise ValueError(data)

    def __upload_file(self, file_path, type='file'):
        # '''上传临时文件'''
        if not os.path.exists(file_path):
            raise ValueError("{},文件不存在".format(file_path))
        file_name = file_path.split("\\")[-1]

        token = self.__get_token()
        with open(file_path, 'rb') as f:
            file_content = f.read()

        files = {'filefield': (file_name, file_content, 'text/plain')}
        # return files
        url = "https://qyapi.weixin.qq.com/cgi-bin/media/upload?access_token={}&type={}".format(token, type)
        r = self.http.request('POST', url, fields=files)
        req = r.data.decode("utf-8")
        # req = r.data.decode("utf-8")
        data = json.loads(req)
        # print(data)
        if data["errcode"] == 0:
            return data['media_id']
        else:
            raise ValueError(data)

    def send_file_message(self, file_path):
        token = self.__get_token()

        media_id = self.__upload_file(file_path)
        # return media_id
        # print(media_id)
        body = {
            "agentid": self.agentid,  # agentid
            "touser": self.touser,
            "chatid": self.chatid,
            "msgtype": "file",  # 消息类型，此时固定为：file
            "file": {"media_id": media_id},  # 文件id，可以调用上传临时素材接口获取
            "safe": 0  # 表示是否是保密消息，0表示否，1表示是
        }
        if self.chatid == "":
            url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={}".format(token)
        else:
            url = "https://qyapi.weixin.qq.com/cgi-bin/appchat/send?access_token={}".format(token)
        bodyjson = json.dumps(body)
        r = self.http.request('POST', url, body=bodyjson)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            # print("发送文件到企业微信成功")
            return data
        else:
            raise ValueError(data)

def send_message(config, message, touser):
    corpid = config["corpid_me"]
    secret = config["corpsecret_me"]
    agentid = config["agentId_me"]
    url1 = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=" + corpid + "&corpsecret=" + secret
    res = requests.get(url=url1)
    # print(res.text)
    access_token = json.loads(res.text)['access_token']
    url2 = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=" + access_token
    message_js = {
        "touser": touser,
        "msgtype": "text",
        "agentid": agentid,
        "text": {"content": message},
        "safe": 0,
        "enable_id_trans": 0,
        "enable_duplicate_check": 0,
        "duplicate_check_interval": 1800
    }
    res = requests.post(url=url2, json=message_js)




def run(config,dict_oprate_data,submit,invoice_check_flag,local_path):


    # try:

    """发票抬头没有映射关系的直接过滤"""
    envir_map = {
        1: "produce",
        0: "prepare",
        2: "test",
    }

    dict_rpa_url_mye = json.loads(config.get(f'mye_database_{envir_map.get(submit)}'))
    with pymssql.connect(host=dict_rpa_url_mye['host'], port=int(dict_rpa_url_mye['port']),
                         user=dict_rpa_url_mye['user'],
                         password=dict_rpa_url_mye['password'], database=dict_rpa_url_mye['database']) as myRPADB:
        cursor = myRPADB.cursor()
        sql = """SELECT
                              tb_ru_sys_param.param_key,
                              tb_ru_sys_param.param_value,
                              tb_ru_sys_param.param_value_en,
                              tb_ru_sys_param.type,
                              tb_ru_sys_param.id,
                              tb_ru_sys_param.note
                            FROM
                              tb_ru_sys_param with(nolock)
                                INNER JOIN tb_ru_sys_param_group with(nolock) ON tb_ru_sys_param.group_id= tb_ru_sys_param_group.id
                            WHERE
                              tb_ru_sys_param_group.group_id = 'cosco_mapping_company'
                              AND tb_ru_sys_param.status= 'ENABLE'
                              AND tb_ru_sys_param_group.status= 'ENABLE'"""
        cursor.execute(sql)
        com_config_res = cursor.fetchall()
        """客户"""
        sql = """SELECT
                              tb_ru_sys_param.param_key,
                              tb_ru_sys_param.param_value,
                              tb_ru_sys_param.param_value_en,
                              tb_ru_sys_param.type,
                              tb_ru_sys_param.id,
                              tb_ru_sys_param.note
                            FROM
                              tb_ru_sys_param with(nolock)
                                INNER JOIN tb_ru_sys_param_group with(nolock) ON tb_ru_sys_param.group_id= tb_ru_sys_param_group.id
                            WHERE
                              tb_ru_sys_param_group.group_id = 'cosco_mapping_customer'
                              AND tb_ru_sys_param.status= 'ENABLE'
                              AND tb_ru_sys_param_group.status= 'ENABLE'"""
        cursor.execute(sql)
        customer_config_res = cursor.fetchall()
        com_config_list = [item[1] for item in com_config_res]
        com_config_map = {item[1]: item for item in com_config_res}
        customer_config_map = {item[1]: item for item in customer_config_res}




    for oprate_data_item in dict_oprate_data["query_data"]:
        task_mode = oprate_data_item["task_mode"]
        platform = oprate_data_item["platform"]
        current_task_id = oprate_data_item["current_task_id"]
        # invoice_check_flag = oprate_data_item["invoice_check_flag"]
        # submit = oprate_data_item["submit"]
        customer_number = oprate_data_item["customer_number"]
        payer = oprate_data_item["payer"]
        payer_en = oprate_data_item["payer_en"]
        company_name = oprate_data_item["company_name"]
        company_code = oprate_data_item["company_code"]
        invoice_billing_company_list = oprate_data_item['invoice_billing_company_list']
        invoice_issuing_company_list = oprate_data_item['invoice_issuing_company_list']

        # 查询当前账号关联的财务同事企业微信账号：
        """暂时没有配置表后续不上"""
        wechat_touser = "nkgjayw"

        if submit == 1:
            connect_name = "connectInfoRPA"
        else:
            connect_name = "connectInfoRPA_test"
        dict_rpa_url = json.loads(config[connect_name])
        with pymysql.connect(host=dict_rpa_url['host'], port=int(dict_rpa_url['port']), user=dict_rpa_url['user'],
                             password=dict_rpa_url['password'], database=dict_rpa_url['database'],
                             charset=dict_rpa_url["charset"]) as mydb:
            with mydb.cursor() as cursor:
                # try:
                # "获取动态报错信息配置"
                sql = f"select * from T00_SYS_00_B_ERROR_MESSAGE_MAP where carrier='{platform}' and b_type='B3'"
                cursor.execute(sql)
                res = cursor.fetchall()
                error_message_map = {item[2]: {"cn": item[5], "en": item[6],"variable_map": json.loads(item[7])} for item in res}

                # 记录启动
                login_data = {
                    "userid": config.get("02205MyeUserInfo").split("|")[0],
                    "passwd": config.get("02205MyeUserInfo").split("|")[1],
                }
                headers = {
                    "Content-Type": "application/json"
                }
                prefixUrlMap = {
                    0: "https://staging.myeverok.com",
                    1: "https://myeverok.com",
                    2: "https://test.myeverok.com",
                }
                mye_prefix_url = prefixUrlMap.get(submit)
                mye_login_url = f"{mye_prefix_url}/apicenter/v1/login"
                mye_add_charge_check_url = f"{mye_prefix_url}/fmsoperation/chargeCheck/addChargeChecks"
                mye_upload_invoicefile_url = f"{mye_prefix_url}/fmsoperation/chargeCheck/uploadInvoiceFile"
                response = requests.post(url=mye_login_url, json=login_data, headers=headers, timeout=15)
                res = response.json()
                token = res.get("content")
                # except Exception as e:
                #     variable_map = {"PLATFORM": platform}
                #     error_message = get_error_message(error_message_map, 'ERR_CODE_800002', variable_map)
                #     send_message(config, error_message, wechat_touser)
                #     raise Exception(error_message)




                # 1对账+发票；2对账；3发票
                if task_mode == "1" or task_mode =="3":

                    # 处理发票
                    for invoice_info_item in oprate_data_item["invoice_info"]:
                        invoice_number = invoice_info_item["invoice_number"]
                        currency = invoice_info_item["currency"]
                        amount = invoice_info_item["amount"]
                        tax_rate = invoice_info_item["tax_rate"]
                        invoicing_date = invoice_info_item["invoicing_date"]
                        issuing_company = invoice_info_item["issuing_company"]
                        billing_company = invoice_info_item["billing_company"]
                        invoice_save_path = invoice_info_item['invoice_save_path']
                        # try:
                        ftp = ftplib.FTP()
                        ftp.connect(config['ftpHostNew'], int(config['ftpPortNew']))
                        # 登录 FTP 服务器
                        ftp.login(config['ftpUserNew'], config['ftpPwdNew'])

                        local_folder = os.path.join(local_path,"pdf_download")
                        if not os.path.exists(local_folder):
                            os.makedirs(local_folder)
                        local_invoice_save_path = os.path.join(local_folder,invoice_number+'.pdf')
                        if os.path.exists(local_invoice_save_path):
                            os.remove(local_invoice_save_path)
                        # except Exception as e:
                        #     variable_map = {"PLATFORM": platform}
                        #     error_message = get_error_message(error_message_map,'ERR_CODE_300001',variable_map)
                        #     send_message(config,error_message,wechat_touser)
                        #     raise Exception(error_message)

                        if invoice_check_flag =="1":
                            if billing_company not in invoice_billing_company_list  or issuing_company not in invoice_issuing_company_list:
                                variable_map = {"error_code":"ERR_CODE_600002","variable_map":{"PLATFORM":platform,"INVOICE_NUMBER":invoice_number,"INVOICING_DATE":invoicing_date,"BILLING_COMPANY":billing_company,"ISSUING_COMPANY":issuing_company}}
                                error_message = get_error_message(error_message_map, 'ERR_CODE_600002',
                                                                  variable_map)
                                send_message(config, error_message, wechat_touser)
                                raise Exception(error_message)




                        # try:

                        # 打开本地文件以写入二进制数据
                        with open(local_invoice_save_path, 'wb') as local_file:
                            # 从 FTP 服务器下载文件
                            ftp.retrbinary('RETR ' + invoice_save_path, local_file.write)
                        # 关闭 FTP 连接
                        ftp.quit()


                        invoice_pdf_name = os.path.basename(local_invoice_save_path)
                        content_type = mimetypes.guess_type(local_invoice_save_path)[0] or 'application/octet-stream'
                        data = {
                            "file": (invoice_pdf_name, open(local_invoice_save_path, "rb"), content_type),
                            "invoiceNo": invoice_number,
                        }
                        Multipartdata = MultipartEncoder(data)
                        invoice_headers = {
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36",
                            "Content-Type": Multipartdata.content_type,
                            "Authorization": token,
                        }
                        response = requests.post(url=mye_upload_invoicefile_url, data=Multipartdata,
                                                     headers=invoice_headers, timeout=30)
                        res = response.json()
                        if response.status_code != 200:
                            raise Exception(f"发票回写接口报错{res}")


                        # except Exception as e:
                        #     variable_map = {"PLATFORM": platform, "INVOICE_NUMBER": invoice_number,
                        #                     "INVOICING_DATE": invoicing_date}
                        #     error_message = get_error_message(error_message_map, 'ERR_CODE_300003', variable_map)
                        #     send_message(config, error_message, wechat_touser)
                        #     raise Exception(error_message)

                        # try:
                        sql = "INSERT INTO T02_BUSI_02208304_INVOICE_DATA (TASK_ID,PLATFORM, COMPANY_NAME, COMPANY_CODE, INVOICE_NUM, CURRENCY, AMOUNT, TAX_RATE, INVOICING_DATE, ISSUING_COMPANY, BILLING_COMPANY, INVOICE_SAVE_PATH,CREATE_TIME) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW());"
                        list_insert = [current_task_id, platform, company_name, company_code, invoice_number, currency,
                                       amount, tax_rate, invoicing_date, issuing_company, billing_company,
                                       invoice_save_path]
                        cursor.execute(sql, list_insert)
                        mydb.commit()
                        # except Exception as e:
                        #     variable_map = {"PLATFORM": platform, "INVOICE_NUMBER": invoice_number,
                        #                     "INVOICING_DATE": invoicing_date}
                        #     error_message = get_error_message(error_message_map, 'ERR_CODE_800001', variable_map)
                        #     send_message(config, error_message, wechat_touser)
                        #     raise Exception(error_message)

                if task_mode == "1" or task_mode =="2":
                    # try:
                    list_invoice = []
                    for bill_info_item in oprate_data_item["bill_info"]:
                        invoice_number = bill_info_item['invoice_number']
                        invoicing_date = bill_info_item['invoicing_date']
                        billing_company = bill_info_item['payer']
                        issuing_company = bill_info_item['issuing_company']


                        if [invoice_number,invoicing_date,billing_company,issuing_company] not in list_invoice:
                            list_invoice.append([invoice_number,invoicing_date,billing_company,issuing_company])

                    # 处理账单数据
                    headers = {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36",
                        "Content-Type": "application/json",
                        "Authorization": token,
                    }
                    data = {
                        "invoiceVOList": []
                    }
                    list_insert = []
                    for invooce_info in list_invoice:
                        invoice_number = invooce_info[0]
                        invoicing_date = invooce_info[1]
                        billing_company = invooce_info[2]
                        issuing_company = invooce_info[3]
                        invoiceVOList = {
                            "invoiceNo": invoice_number,  # 发票号
                            "invoiceTime": invoicing_date + " 00:00:00",  # 开票日期
                            "clearingHouseCode": com_config_map.get(billing_company)[0],  # 客户自编号 订舱公司code
                            "clearingHouseName": billing_company,  # 付费人名称
                            "clearingHouseNameEn": com_config_map.get(billing_company)[2],  # 付费人英文名称
                            'customerId':customer_config_map.get(issuing_company)[0],
                            'customerName':issuing_company,
                            'customerNameEn':customer_config_map.get(issuing_company)[1],
                            'sourceType':1,
                            "checkBlVOList": []
                        }
                        bill_amount_total = 0
                        for bill_info_item in oprate_data_item["bill_info"]:
                            if bill_info_item['invoice_number'] !=invoice_number or bill_info_item['invoicing_date'] !=invoicing_date:
                                continue


                            mbl_no = bill_info_item["mbl_no"]
                            charge_name = bill_info_item["charge_name"]
                            transaction_date = bill_info_item["transaction_date"]
                            USD_total = bill_info_item['usdTotal']
                            if USD_total:
                                bill_amount_total += USD_total
                            CNY_total = bill_info_item['rmbTotal']
                            if CNY_total:
                                bill_amount_total += CNY_total

                            currency = bill_info_item["currency"]
                            vessel = bill_info_item["vessel"]
                            voyage_no = bill_info_item["voyage_no"]
                            container_type = bill_info_item["container_type"]
                            container_number = bill_info_item["container_number"]
                            shipping_terms = bill_info_item["shipping_terms"]
                            remark = bill_info_item["remark"]

                            invoiceVOList['checkBlVOList'].append({
                                "mblNo": mbl_no,  # 提单号
                                "costName": charge_name,  # 费用名称
                                "businessTime": transaction_date,  # 业务日期
                                "usdTotal": USD_total,  # 美金合计
                                "rmbTotal": CNY_total,  # 人民币合计
                                "invoiceCurrency": currency,  # 发票币种
                                "vsl": vessel,  # 船名
                                "voy": voyage_no,  # 航次/航向
                                "container": container_type+'*'+container_number,  # 箱型箱量
                                "hblTransportterms": shipping_terms,  # 运输条款
                                "notes": remark,  # 托单备注
                                "clearingHouseCode": com_config_map.get(billing_company)[0],  # 客户自编号
                                "clearingHouseName": billing_company,  # 付费人名称
                                "clearingHouseNameEn": com_config_map.get(billing_company)[2]  # 付费人英文名称
                            })
                            list_insert.append([
                                current_task_id,platform,company_name,company_code,customer_number,payer,payer_en,mbl_no,invoice_number,invoicing_date,charge_name,transaction_date,USD_total,CNY_total,currency,vessel,voyage_no,container_type,container_number,shipping_terms,remark
                            ])
                        invoiceVOList['costAmount'] = bill_amount_total
                    data['invoiceVOList'].append(invoiceVOList)
                    response = requests.post(mye_add_charge_check_url, json=data, headers=headers)
                    res = response.json()
                    if response.status_code != 200:
                        raise Exception(f"账单回写接口报错{res}")

                    sql = "INSERT INTO T02_BUSI_02208305_BILL_DATA (TASK_ID, PLATFORM, COMPANY_NAME, COMPANY_CODE, CUSTOMER_NUMBER, PAYER, PAYER_EN, MBL_NO, INVOICE_NUM, INVOICING_DATE, CHARGE_NAME, TRANSACTION_DATE, USD_TOTAL, CNY_TOTAL, CURRENCY, VESSEL, VOYAGE_NO, CONTAINER_TYPE, CONTAINER_NUMBER, SHIPPING_TERMS, REMARK,CREATE_TIME) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW());"
                    cursor.executemany(sql, list_insert)
                    mydb.commit()
                    # except Exception as e:
                    #     variable_map = {"platform": platform}
                    #     error_message = get_error_message(error_message_map, 'ERR_CODE_300003', variable_map)
                    #     send_message(config, error_message, wechat_touser)
                    #     raise Exception(error_message)
                # try:
                sql= "update T02_BUSI_02208302_TASK_RECORD set STATUS= 'Done' where ID = %s"
                cursor.execute(sql,[current_task_id])

                sql = "update T02_BUSI_02208301_USER_COF set HANDLE_TIME= NOW() where PLATFORM = %s AND COMPANY_NAME = %s AND COMPANY_CODE = %s"
                cursor.execute(sql, [platform,company_name,company_code])
                mydb.commit()
                cursor.close()
                # except Exception as e:
                #     variable_map = {"platform": platform}
                #     error_message = get_error_message(error_message_map, 'ERR_CODE_300004', variable_map)
                #     send_message(config, error_message, wechat_touser)
                #     raise Exception(error_message)
    # except Exception as e:
    #     variable_map = {}
    #     error_message = get_error_message(error_message_map, 'ERR_CODE_300000', variable_map)
    #     send_message(config, error_message, wechat_touser)
    #     raise Exception(error_message)



if __name__ == '__main__':

    platform = "中外运"
    company_code = ""
    task_mode = '1'
    machine_code = "5E15345E7A215F380A36"
    config = getConfig(machine_code)
    dict_oprate_data = {}
    submit = 0
    invoice_check_flag = None
    local_path = r'D:\智慧恒通\项目开发\6.0_new\Task022083_中外运_B3_费用与发票获取\MainProcess\res'
    dict_oprate_data = {
	"query_data" : 
	[
		{
			"bill_amount_total" : "2045",
			"bill_info" : 
			[
				{
					"charge_name" : "舱单删单费",
					"container_number" : "",
					"container_type" : "",
					"currency" : "CNY",
					"invoice_number" : "24317000000869698329",
					"invoicing_date" : "2024-11-21",
					"issuing_company" : "中国外运华东有限公司海运分公司",
					"mbl_no" : "177FASASS303016",
					"payer" : "智慧恒通(江苏)供应链科技集团有限公司",
					"remark" : "",
					"rmbTotal" : 400,
					"shipping_terms" : "",
					"transaction_date" : "",
					"usdTotal" : 0.0,
					"vessel" : "MSC MICHIGAN VII",
					"voyage_no" : "QB439W"
				},
				{
					"charge_name" : "舱单服务费",
					"container_number" : "",
					"container_type" : "",
					"currency" : "CNY",
					"invoice_number" : "24317000000869698329",
					"invoicing_date" : "2024-11-21",
					"issuing_company" : "中国外运华东有限公司海运分公司",
					"mbl_no" : "177FASASS303016",
					"payer" : "智慧恒通(江苏)供应链科技集团有限公司",
					"remark" : "",
					"rmbTotal" : 20,
					"shipping_terms" : "",
					"transaction_date" : "",
					"usdTotal" : 0.0,
					"vessel" : "MSC MICHIGAN VII",
					"voyage_no" : "QB439W"
				},
				{
					"charge_name" : "舱单费",
					"container_number" : "",
					"container_type" : "",
					"currency" : "CNY",
					"invoice_number" : "24317000000869698329",
					"invoicing_date" : "2024-11-21",
					"issuing_company" : "中国外运华东有限公司海运分公司",
					"mbl_no" : "177FASASS303016",
					"payer" : "智慧恒通(江苏)供应链科技集团有限公司",
					"remark" : "",
					"rmbTotal" : 25,
					"shipping_terms" : "",
					"transaction_date" : "",
					"usdTotal" : 0.0,
					"vessel" : "MSC MICHIGAN VII",
					"voyage_no" : "QB439W"
				},
				{
					"charge_name" : "滞箱/超期费",
					"container_number" : "",
					"container_type" : "",
					"currency" : "CNY",
					"invoice_number" : "24317000000869698329",
					"invoicing_date" : "2024-11-21",
					"issuing_company" : "中国外运华东有限公司海运分公司",
					"mbl_no" : "HDMUSHAZKYA28900",
					"payer" : "智慧恒通(江苏)供应链科技集团有限公司",
					"remark" : "",
					"rmbTotal" : 800,
					"shipping_terms" : "",
					"transaction_date" : "",
					"usdTotal" : 0.0,
					"vessel" : "HYUNDAI VANCOUVER",
					"voyage_no" : "0295W"
				},
				{
					"charge_name" : "滞箱/超期费",
					"container_number" : "",
					"container_type" : "",
					"currency" : "CNY",
					"invoice_number" : "24317000000869698329",
					"invoicing_date" : "2024-11-21",
					"issuing_company" : "中国外运华东有限公司海运分公司",
					"mbl_no" : "HDMUSHAZFYJ20200",
					"payer" : "智慧恒通(江苏)供应链科技集团有限公司",
					"remark" : "",
					"rmbTotal" : 400,
					"shipping_terms" : "",
					"transaction_date" : "",
					"usdTotal" : 0.0,
					"vessel" : "HYUNDAI VANCOUVER",
					"voyage_no" : "0295W"
				},
				{
					"charge_name" : "滞箱/超期费",
					"container_number" : "",
					"container_type" : "",
					"currency" : "CNY",
					"invoice_number" : "24317000000869698329",
					"invoicing_date" : "2024-11-21",
					"issuing_company" : "中国外运华东有限公司海运分公司",
					"mbl_no" : "HDMUSHAZFYP43100",
					"payer" : "智慧恒通(江苏)供应链科技集团有限公司",
					"remark" : "",
					"rmbTotal" : 400,
					"shipping_terms" : "",
					"transaction_date" : "",
					"usdTotal" : 0.0,
					"vessel" : "HYUNDAI VANCOUVER",
					"voyage_no" : "0295W"
				}
			],
			"company_code" : "EKNKG",
			"company_name" : "智慧恒通(江苏)供应链科技集团有限公司",
			"current_task_id" : 42,
			"customer_number" : "",
			"invoice_billing_company_list" : None,
			"invoice_info" : 
			[
				{
					"amount" : "2045",
					"billing_company" : "智慧恒通(江苏)供应链科技集团有限公司",
					"currency" : "CNY",
					"invoice_number" : "24317000000869698329",
					"invoice_save_path" : "/task022083/zwy/24317000000869698329.pdf",
					"invoicing_date" : "2024-11-21",
					"issuing_company" : "中国外运华东有限公司海运分公司",
					"tax_rate" : ''
				}
			],
			"invoice_issuing_company_list" : None,
			"payer" : "智慧恒通(江苏)供应链科技集团有限公司",
			"payer_en" : "",
			"platform" : "中外运",
			"task_mode" : "1"
		}
	]
}
    run(config, dict_oprate_data, submit, invoice_check_flag, local_path)


